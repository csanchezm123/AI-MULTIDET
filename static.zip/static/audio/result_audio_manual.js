document.addEventListener("DOMContentLoaded", function () {
    updateRing(percentage);
    updatePercentageText(percentage);
});

function updateRing(targetPercentage) {
    const circle = document.querySelector('.circle');
    let currentPercentage = 0;

    const interval = setInterval(() => {
        if (currentPercentage <= targetPercentage) {
            const angle = (currentPercentage / 100) * 360;
            const color = getRingColor(currentPercentage);


            circle.style.background = `conic-gradient(${color} 0deg ${angle}deg, #eee ${angle}deg 360deg)`;
            
            const percentageText = document.getElementById("percentage-text");
            percentageText.style.color = color;

            currentPercentage++;
        } else {
            clearInterval(interval);
        }
    }, 30); 
}


function getRingColor(percentage) {
    if (percentage <= 33) {
        return '#4ed64e';
    } else if (percentage > 33 && percentage <= 66) {
        return '#faa328';
    } else {
        return '#ff5e1f';
    }
}

function updatePercentageText(percentage) {
    const percentageText = document.getElementById("percentage-text");
    let currentValue = 0;

    const interval = setInterval(() => {
        if (currentValue < percentage) {
            currentValue++;
            percentageText.innerText = `${currentValue.toFixed(2)}%`;
        } else {
            percentageText.innerText = `${percentage.toFixed(2)}%`;
            clearInterval(interval);
        }
    }, 30);
}
